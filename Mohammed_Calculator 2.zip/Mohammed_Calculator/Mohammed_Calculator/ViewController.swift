//
//  ViewController.swift
//  Mohammed_Calculator
//
//  Created by Mohammed,Shahid on 2/17/22.
//

import UIKit

class ViewController: UIViewController {


    
    @IBOutlet weak var displayLabel: UILabel!
    
    var inputValueOne = ""

    var inputValueTwo = ""
    var operation = ""
    var operationValueChanged = false
    var calculatedValue = ""
    var differentOperators = false
    var result = ""
    var inChain = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonNine(_ sender: UIButton) {
       /* let number = "9"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("9")
    
    }
    
    @IBAction func buttonEight(_ sender: UIButton) {
      /*  let number = "8"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("8")
        
    }
    @IBAction func buttonSeven(_ sender: UIButton) {
       /* let number = "7"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("7")
    }
    @IBAction func buttonSix(_ sender: UIButton) {
       /* let number = "6"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("6")
    }
    @IBAction func buttonFive(_ sender: UIButton) {
      /*  let number = "5"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("5")
    }
    @IBAction func buttonFour(_ sender: UIButton) {
       /* let number = "4"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("4")
    }
    @IBAction func buttonThree(_ sender: UIButton) {
      /*  let number = "3"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("3")
    }
    @IBAction func buttonTwo(_ sender: UIButton) {
       /* let number = "2"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("2")
    }
    @IBAction func buttonOne(_ sender: UIButton) {
       /* let number = "1"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("1")
    }
    @IBAction func buttonZero(_ sender: UIButton) {
       /* let number = "0"
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData("0")
    }
    @IBAction func buttonDot(_ sender: UIButton) {
      /*  let number = "."
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            if !differentOperators {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }*/
        setData(".")
    }
    @IBAction func buttonAC(_ sender: UIButton) {
        inputValueTwo = ""
        inputValueOne = ""
        viewDidLoad()
        operationValueChanged = false
        print(11)
        operation = ""
        calculatedValue = ""
        displayLabel.text = ""
        displayLabel.textColor = .red
        print(00)
        differentOperators=false
        inChain = false
        
    }
  
    @IBAction func buttonPlusOrMinus(_ sender: UIButton) {
        
        if inputValueOne != "" {
            
            displayLabel.text = "-" + String(displayLabel.text!)
            inputValueOne = "\(displayLabel.text!)"
        }
        else{
            displayLabel.text = "-" + String(displayLabel.text!)
            inputValueTwo = "\(displayLabel.text!)"
        }
        
    }
@IBAction func buttonModulus(_ sender: UIButton) {
    let value = calTemp(operation)
    operation = "/"
    displayLabel.text = (value != "") ? resultFormatter(value) : ""
    if value != "" {
        if inputValueTwo != ""{
            inChain = true
            differentOperators = true
            if operationValueChanged {
                result = String(Double(value)! / Double(inputValueTwo)!)
                if result == "inf"{
                    displayLabel.text! = "Error"
                }else{
                    displayLabel.text! = resultFormatter(result)
                }
            }
        }
    }
    operationValueChanged = true
}
@IBAction func buttonMultiply(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "*"
        calculatedValue=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        operationValueChanged=true
        
        
    }
    
    @IBAction func buttonSubtract(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "-"
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        print("123")
        if temp != "" {
                    if inputValueTwo != ""{
                        inChain = true
                differentOperators = true
                calculatedValue = inputValueTwo;
                if operationValueChanged {
                    result = String(Double(temp)! - Double(inputValueTwo)!)
                    displayLabel.text! = resultFormatter(result)
                }
            }
        }
        operationValueChanged = true
        
    }
    
    @IBAction func Div(_ sender: UIButton) {
            let temp = calTemp(operation)
            operation = "/"
            displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
              if temp != "" {
                  //            inChainmode = true
                  if inputValueTwo != ""{
                      inChain = true
                      
                      if operationValueChanged {
                          result = String(Double(temp)! / Double(inputValueTwo)!)
                          print(result)
                          if result == "inf"{
                            displayLabel.text! = "Error"
                          }else{
                            displayLabel.text! = resultFormatter(result)
                          }
                      }
                  }
              }
              operationValueChanged = true
            
        }
    @IBAction func buttonPlus(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "+"
        calculatedValue=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        operationValueChanged=true
        
    }
    @IBAction func buttonEquals(_ sender: UIButton) {
        var result = ""
        switch operation {
        case "+":
            
            if calculatedValue != "" {
                result = String(Double(inputValueOne)! + Double(calculatedValue)!)
                displayLabel.text = resultFormatter(result)
                 inputValueTwo = calculatedValue
            }else{

                result = String(Double(inputValueOne)! + Double(inputValueTwo)!)
                displayLabel.text = resultFormatter(result)
            }
            inputValueOne = result
            
            break
        case "*":
            if calculatedValue != "" {
                result = String(Double(inputValueOne)! * Double(calculatedValue)!)
                displayLabel.text = resultFormatter(result)
            }else{
                result = String(Double(inputValueOne)! * Double(inputValueTwo)!)
                displayLabel.text = resultFormatter(result)
            }
            inputValueOne = result
            
            break
        case "-":
            if calculatedValue != "" {
                result = String(Double(inputValueOne)! - Double(calculatedValue)!)
                displayLabel.text = resultFormatter(result)
                //                number2 = ""
            }else{
                result = String(Double(inputValueOne)! - Double(inputValueTwo)!)
                displayLabel.text = resultFormatter(result)
            }
            inputValueOne = result
            break
        case "/":
            if displayLabel.text == "Error"{
                inputValueTwo = ""
                inputValueOne = ""
                operationValueChanged = false
                operation = ""
                calculatedValue = ""
                displayLabel.text = "0"
                differentOperators=false
            }else{
                if calculatedValue != "" {
                    result = String(Double(inputValueOne)! / Double(calculatedValue)!)
                    if result == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }else{
                        displayLabel.text = resultFormatter(result)
                    }
                }else{
                    result = String(Double(inputValueOne)! / Double(inputValueTwo)!)
                    if result == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }else{
                        displayLabel.text = resultFormatter(result)
                    }
                }
                inputValueOne = result
            }
            break
        default:
            print("Nothing")
        }
        
    }
//    @IBAction func sqaureRootButton(_ sender: UIButton) {
//        if displayLabel.text == "" || displayLabel.text == "0"{
//            return
//        }
//        let squareRoot = displayLabel.text
//        displayLabel.text = resultFormatter(String(Double(squareRoot!)!.squareRoot()))
//        inputValueOne = displayLabel.text!
//        inputValueTwo = ""
//
//    }
    
    func setData(_ number: String){
        print(inChain)
        if displayLabel.text == "0"{
            displayLabel.text = ""
            displayLabel.textColor = .white
        }
        if !operationValueChanged {
            displayLabel.text! += number
            inputValueOne += number
        }else{
            print(inChain)
            if !inChain {
                displayLabel.text! += number
                inputValueTwo += number
            }else {
                displayLabel.text = ""
                displayLabel.text! += number
                inputValueTwo += number
            }
        }
    }
    
    func calTemp(_ operation:String)->String {
        if inputValueOne != "" && inputValueTwo != ""{
            if operation == "+"{
                inputValueOne = String(Double(inputValueOne)! + Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
                //                return String(Double(number1)! + Double(number2)!)
            }
            if operation == "-"{
                inputValueOne = String(Double(inputValueOne)! - Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
            }
            if operation == "*"{
                inputValueOne = String(Double(inputValueOne)! * Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
            }
            if operation == "/"{
                inputValueOne = String(Double(inputValueOne)! / Double(inputValueTwo)!)
                calculatedValue = inputValueTwo
                inputValueTwo = ""
                return String(inputValueOne)
            }
        }
        return ""
    }
    
    func resultFormatter(_ result:String)->String {
        let value = Double(result)!
        var resultStr = String(round(value * 100000) / 100000.0)
        
        if resultStr.contains(".0"){
            resultStr.removeSubrange(resultStr.index(resultStr.endIndex, offsetBy: -2)..<resultStr.endIndex)
        }
        
        return resultStr
    }
    
    @IBAction func clearButton(_ sender: Any) {
        inputValueTwo = ""
        inputValueOne = ""
        viewDidLoad()
        operationValueChanged = false
        print(11)
        operation = ""
        calculatedValue = ""
        displayLabel.text = "0"
        displayLabel.textColor = .red
        print(00)
        differentOperators=false
        inChain = false
    }
    
    /*@IBAction func ClearButton(_ sender: UIButton) {
            inputValueTwo = ""
            displayLabel.text = ""
        }
     */
    
    
    


}
